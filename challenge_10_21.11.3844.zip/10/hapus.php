<?php
require_once 'koneksi.php';
//21.11.3844
// Memeriksa apakah parameter id tersedia
if (isset($_GET['id'])) {
    $nim = $_GET['id'];

    // Menghapus data mahasiswa berdasarkan NIM
    $sql = "DELETE FROM mahasiswa WHERE nim = '$nim'";
    if ($conn->query($sql) === TRUE) {
        echo "Data mahasiswa dengan NIM $nim berhasil dihapus.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Parameter NIM tidak ditemukan.";
}
?>

<a href="index.php" class="btn btn-primary mt-3">Kembali</a>

<?php
// Menutup koneksi
$conn->close();
?>