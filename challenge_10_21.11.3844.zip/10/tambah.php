<?php
require_once 'koneksi.php';

// Memeriksa apakah form telah dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nim = $_POST["nim"];
    $nama = $_POST["nama"];
    $nohp = $_POST["nohp"];
    $jenis_kelamin = $_POST["jenis_kelamin"];
    $jurusan = $_POST["jurusan"];
    $alamat = $_POST["alamat"];

    // Menyimpan data ke database
    $sql = "INSERT INTO mahasiswa (nim, nama, nohp, jenis_kelamin, jurusan, alamat)
            VALUES ('$nim', '$nama', '$nohp', '$jenis_kelamin', '$jurusan', '$alamat')";

    if ($conn->query($sql) === TRUE) {
        echo "Data mahasiswa berhasil disimpan.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Challenge-10-21.11.3844-tambah</title>
   
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-body">
                <h2 class="card-title text-center">Form Mahasiswa</h2>
                <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
                    <div class="mb-3">
                        <label for="nim" class="form-label">NIM:</label>
                        <input type="text" id="nim" name="nim" required class="form-control">
                    </div>

                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama:</label>
                        <input type="text" id="nama" name="nama" required class="form-control">
                    </div>

                    <div class="mb-3">
                        <label for="nohp" class="form-label">No HP:</label>
                        <input type="text" id="nohp" name="nohp" required class="form-control">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Jenis Kelamin:</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="jenis_kelamin" id="laki-laki" value="Laki-laki" required>
                            <label class="form-check-label" for="laki-laki">Laki-laki</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="jenis_kelamin" id="perempuan" value="Perempuan" required>
                            <label class="form-check-label" for="perempuan">Perempuan</label>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="jurusan" class="form-label">Jurusan:</label>
                        <input type="text" id="jurusan" name="jurusan" required class="form-control">
                    </div>

                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat:</label>
                        <textarea id="alamat" name="alamat" required class="form-control"></textarea>
                    </div>

                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="index.php" class="btn btn-primary ">Kembali</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>

<?php
// Menutup koneksi
$conn->close();
?>