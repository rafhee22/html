

<!DOCTYPE html>
<html>
<head>
    <title>Challenge-10-21.11.3844-home</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Tabel Mahasiswa</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>No HP</th>
                    <th>Jenis Kelamin</th>
                    <th>Jurusan</th>
                    <th>Alamat</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Mengambil data mahasiswa dari database
                require_once 'koneksi.php';
                $sql = "SELECT * FROM mahasiswa";
                $result = $conn->query($sql);
                
                // Menutup koneksi
                $conn->close();
            
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["nim"] . "</td>";
                        echo "<td>" . $row["nama"] . "</td>";
                        echo "<td>" . $row["nohp"] . "</td>";
                        echo "<td>" . $row["jenis_kelamin"] . "</td>";
                        echo "<td>" . $row["jurusan"] . "</td>";
                        echo "<td>" . $row["alamat"] . "</td>";
                        echo "<td>
                        <a href='hapus.php?id=" . $row["nim"] . "' class='btn btn-danger'>Hapus</a>  
                        <a href='edit.php?id=" . $row["nim"] . "' class='btn btn-primary btn-edit'>Edit</a>  
                      </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>Tidak ada data mahasiswa</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <a href="tambah.php" class="btn btn-primary mb-3">Tambah Mahasiswa</a>
    </div>
</body>
</html>