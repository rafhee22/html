<?php
// Koneksi ke database
//21.11.3844
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "datamahasiswa";
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>