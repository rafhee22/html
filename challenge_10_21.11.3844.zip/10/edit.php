<?php

require_once 'koneksi.php';
// Memeriksa apakah parameter id tersedia
if (isset($_GET['id'])) {
    $nim = $_GET['id'];
//21.11.3844
    // Memperbarui data mahasiswa berdasarkan NIM
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nama = $_POST['nama'];
        $nohp = $_POST['nohp'];
        $jenis_kelamin = $_POST['jenis_kelamin'];
        $jurusan = $_POST['jurusan'];
        $alamat = $_POST['alamat'];

        $sql = "UPDATE mahasiswa SET nama='$nama', nohp='$nohp', jenis_kelamin='$jenis_kelamin', jurusan='$jurusan', alamat='$alamat' WHERE nim='$nim'";
        if ($conn->query($sql) === TRUE) {
            echo "Data mahasiswa dengan NIM $nim berhasil diperbarui.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    // Mengambil data mahasiswa berdasarkan NIM
    $sql = "SELECT * FROM mahasiswa WHERE nim='$nim'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nama = $row['nama'];
        $nohp = $row['nohp'];
        $jenis_kelamin = $row['jenis_kelamin'];
        $jurusan = $row['jurusan'];
        $alamat = $row['alamat'];
    } else {
        echo "Data mahasiswa dengan NIM $nim tidak ditemukan.";
    }
} else {
    echo "Parameter NIM tidak ditemukan.";
}

// Menutup koneksi
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
<title>Challenge-10-21.11.3844-edit</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-body">
                <h2 class="card-title text-center">Edit Mahasiswa</h2>
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"] . "?id=$nim"); ?>">
                    <div class="mb-3">
                        <label for="nim" class="form-label">NIM:</label>
                        <input type="text" id="nim" name="nim" value="<?php echo $nim; ?>" readonly class="form-control">
                    </div>

                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama:</label>
                        <input type="text" id="nama" name="nama" value="<?php echo $nama; ?>" required class="form-control">
                    </div>

                    <div class="mb-3">
                        <label for="nohp" class="form-label">No HP:</label>
                        <input type="text" id="nohp" name="nohp" value="<?php echo $nohp; ?>" required class="form-control">
                    </div>

                    <div class="mb-3">
                        <label for="jenis_kelamin" class="form-label">Jenis Kelamin:</label>
                        <select id="jenis_kelamin" name="jenis_kelamin" required class="form-control">
                            <option value="Laki-laki" <?php if ($jenis_kelamin == 'Laki-laki') echo 'selected'; ?>>Laki-laki</option>
                            <option value="Perempuan" <?php if ($jenis_kelamin == 'Perempuan') echo 'selected'; ?>>Perempuan</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="jurusan" class="form-label">Jurusan:</label>
                        <input type="text" id="jurusan" name="jurusan" value="<?php echo $jurusan; ?>" required class="form-control">
                    </div>

                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat:</label>
                        <textarea id="alamat" name="alamat" required class="form-control"><?php echo $alamat; ?></textarea>
                    </div>

                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="index.php" class="btn btn-primary">Kembali</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>